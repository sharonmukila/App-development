package com.backend.entrpreneurs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EntrpreneursApplication {

	public static void main(String[] args) {
		SpringApplication.run(EntrpreneursApplication.class, args);
	}

}
